"use client"

import { useState } from "react"
import { dataStore, type Shipment } from "@/lib/store"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, CheckCircle2, AlertCircle } from "lucide-react"

export default function CargoStatusManager() {
  const [shipments, setShipments] = useState<Shipment[]>(dataStore.getAllShipments())
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null)
  const [showUpdateDialog, setShowUpdateDialog] = useState(false)
  const [updateData, setUpdateData] = useState({
    city: "",
    country: "",
    status: "in_transit" as const,
  })
  const [searchQuery, setSearchQuery] = useState("")

  const filteredShipments = shipments.filter(
    (s) =>
      s.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.origin.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.destination.city.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleUpdateStatus = () => {
    if (!selectedShipment || !updateData.city.trim() || !updateData.country.trim()) return

    const updated = dataStore.updateShipmentStatus(selectedShipment.id, {
      city: updateData.city,
      country: updateData.country,
      timestamp: new Date(),
      status: updateData.status,
    })

    if (updated) {
      setShipments(shipments.map((s) => (s.id === updated.id ? updated : s)))
      setSelectedShipment(updated)
      setUpdateData({ city: "", country: "", status: "in_transit" })
      setShowUpdateDialog(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCircle2 className="w-5 h-5 text-green-400" />
      case "delayed":
        return <AlertCircle className="w-5 h-5 text-red-400" />
      case "in_transit":
        return <Clock className="w-5 h-5 text-blue-400" />
      default:
        return <MapPin className="w-5 h-5 text-yellow-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-600"
      case "delayed":
        return "bg-red-600"
      case "in_transit":
        return "bg-blue-600"
      default:
        return "bg-yellow-600"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "delivered":
        return "Teslim Edildi"
      case "delayed":
        return "Gecikmeli"
      case "in_transit":
        return "Yolda"
      case "pending":
        return "Bekleniyor"
      default:
        return status
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-1">Kargo Durum Yönetimi</h2>
        <p className="text-purple-300/70">Tüm kargolarının durumunu güncelleyin ve takip edin</p>
      </div>

      {/* Search */}
      <Input
        placeholder="Tracking numarası, kaynak veya hedef şehir ara..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="bg-slate-800/50 border-purple-500/30 text-white placeholder-purple-300/50"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Shipments List */}
        <div className="lg:col-span-1">
          <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Kargolar ({filteredShipments.length})</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredShipments.map((shipment) => (
                  <button
                    key={shipment.id}
                    onClick={() => {
                      setSelectedShipment(shipment)
                      setShowUpdateDialog(false)
                    }}
                    className={`w-full p-3 rounded-lg text-left transition-all ${
                      selectedShipment?.id === shipment.id
                        ? "bg-purple-600/40 border border-purple-400"
                        : "bg-slate-700/30 hover:bg-slate-600/40 border border-transparent"
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      {getStatusIcon(shipment.currentLocation.status)}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-white text-sm truncate">{shipment.trackingNumber}</p>
                        <p className="text-purple-300/70 text-xs">
                          {shipment.origin.city} → {shipment.destination.city}
                        </p>
                        <Badge className={`${getStatusColor(shipment.currentLocation.status)} text-white text-xs mt-1`}>
                          {getStatusLabel(shipment.currentLocation.status)}
                        </Badge>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Shipment Details */}
        <div className="lg:col-span-2">
          {selectedShipment ? (
            <div className="space-y-4">
              {/* Current Status */}
              <Card className="border-purple-500/30 bg-gradient-to-br from-slate-800/50 to-purple-900/20 backdrop-blur">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h4 className="text-xl font-bold text-white mb-1">{selectedShipment.trackingNumber}</h4>
                      <p className="text-purple-300/70 text-sm">Tracking ID</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(selectedShipment.currentLocation.status)}
                      <Badge className={`${getStatusColor(selectedShipment.currentLocation.status)} text-white`}>
                        {getStatusLabel(selectedShipment.currentLocation.status)}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-purple-300/70 text-sm mb-1">Başlangıç</p>
                      <p className="text-white font-medium">{selectedShipment.origin.city}</p>
                      <p className="text-purple-300/70 text-xs">{selectedShipment.origin.country}</p>
                    </div>
                    <div>
                      <p className="text-purple-300/70 text-sm mb-1">Hedef</p>
                      <p className="text-white font-medium">{selectedShipment.destination.city}</p>
                      <p className="text-purple-300/70 text-xs">{selectedShipment.destination.country}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-purple-300/70 text-sm mb-1">Mevcut Konum</p>
                      <p className="text-white font-medium">{selectedShipment.currentLocation.city}</p>
                      <p className="text-purple-300/70 text-xs">{selectedShipment.currentLocation.country}</p>
                      <p className="text-purple-300/50 text-xs mt-1">
                        {new Date(selectedShipment.currentLocation.timestamp).toLocaleString("tr-TR")}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Route Timeline */}
              <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur p-6">
                <h4 className="text-lg font-semibold text-white mb-4">Rota Tarihi</h4>
                <div className="space-y-3">
                  {selectedShipment.route.map((location, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                        {idx < selectedShipment.route.length - 1 && (
                          <div className="w-1 h-12 bg-purple-500/30 my-1"></div>
                        )}
                      </div>
                      <div className="pb-4">
                        <p className="text-white font-medium">
                          {location.city}, {location.country}
                        </p>
                        <p className="text-purple-300/70 text-sm">
                          {new Date(location.timestamp).toLocaleString("tr-TR")}
                        </p>
                        <Badge className={`${getStatusColor(location.status)} text-white text-xs mt-2`}>
                          {getStatusLabel(location.status)}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Update Button */}
              <Button
                onClick={() => setShowUpdateDialog(true)}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                Durumu Güncelle
              </Button>
            </div>
          ) : (
            <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur h-full flex items-center justify-center min-h-96">
              <div className="text-center">
                <p className="text-purple-300/70">Kargo seçin detaiları görmek için</p>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Update Status Dialog */}
      {selectedShipment && (
        <Dialog open={showUpdateDialog} onOpenChange={setShowUpdateDialog}>
          <DialogContent className="border-purple-500/30 bg-slate-900">
            <DialogHeader>
              <DialogTitle className="text-white">Kargo Durumunu Güncelle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-purple-300 mb-2">Şehir</label>
                <Input
                  placeholder="Şehir adını girin"
                  value={updateData.city}
                  onChange={(e) => setUpdateData({ ...updateData, city: e.target.value })}
                  className="bg-slate-800 border-purple-500/30 text-white placeholder-purple-300/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-purple-300 mb-2">Ülke</label>
                <Input
                  placeholder="Ülke adını girin"
                  value={updateData.country}
                  onChange={(e) => setUpdateData({ ...updateData, country: e.target.value })}
                  className="bg-slate-800 border-purple-500/30 text-white placeholder-purple-300/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-purple-300 mb-2">Durum</label>
                <Select
                  value={updateData.status}
                  onValueChange={(value) => setUpdateData({ ...updateData, status: value as any })}
                >
                  <SelectTrigger className="bg-slate-800 border-purple-500/30 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-purple-500/30">
                    <SelectItem value="pending" className="text-white">
                      Bekleniyor
                    </SelectItem>
                    <SelectItem value="in_transit" className="text-white">
                      Yolda
                    </SelectItem>
                    <SelectItem value="delayed" className="text-white">
                      Gecikmeli
                    </SelectItem>
                    <SelectItem value="delivered" className="text-white">
                      Teslim Edildi
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-3 justify-end pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowUpdateDialog(false)}
                  className="border-purple-500/30 text-purple-300 hover:bg-purple-600/10"
                >
                  İptal
                </Button>
                <Button onClick={handleUpdateStatus} className="bg-purple-600 hover:bg-purple-700 text-white">
                  Güncelle
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
