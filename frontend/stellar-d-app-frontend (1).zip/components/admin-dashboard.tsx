"use client"

import { useState, useMemo } from "react"
import { dataStore, type Customer } from "@/lib/store"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ChevronRight, Mail, Phone, MapPin, Package } from "lucide-react"

export default function AdminDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null)
  const customers = dataStore.getAllCustomers()

  const filteredCustomers = useMemo(() => {
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.walletAddress.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }, [searchQuery])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Admin Paneli</h1>
          <p className="text-purple-300">Müşteri yönetimi ve kargo durumu güncelleme</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Customers List */}
          <div className="lg:col-span-1">
            <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-white mb-4">Müşteri Listesi ({customers.length})</h2>

                <Input
                  placeholder="Ad, email veya cüzdan ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="mb-4 bg-slate-700/50 border-purple-500/30 text-white placeholder-purple-300/50"
                />

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {filteredCustomers.map((customer) => (
                    <button
                      key={customer.id}
                      onClick={() => setSelectedCustomer(customer)}
                      className={`w-full p-3 rounded-lg text-left transition-all ${
                        selectedCustomer?.id === customer.id
                          ? "bg-purple-600/40 border border-purple-400"
                          : "bg-slate-700/30 hover:bg-slate-600/40 border border-transparent"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-white text-sm">{customer.name}</p>
                          <p className="text-purple-300/70 text-xs">{customer.walletAddress}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-purple-400" />
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          {/* Customer Details */}
          <div className="lg:col-span-2">
            {selectedCustomer ? (
              <div className="space-y-6">
                {/* Customer Info Card */}
                <Card className="border-purple-500/30 bg-gradient-to-br from-slate-800/50 to-purple-900/20 backdrop-blur">
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <h3 className="text-2xl font-bold text-white">{selectedCustomer.name}</h3>
                        <p className="text-purple-300 text-sm">{selectedCustomer.walletAddress}</p>
                      </div>
                      <Badge className="bg-purple-600 text-white">Müşteri</Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-start gap-3">
                        <Mail className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                        <div>
                          <p className="text-purple-300/70 text-sm">Email</p>
                          <p className="text-white font-medium">{selectedCustomer.email}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <Phone className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                        <div>
                          <p className="text-purple-300/70 text-sm">Telefon</p>
                          <p className="text-white font-medium">{selectedCustomer.phone}</p>
                        </div>
                      </div>
                      <div className="col-span-2 flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
                        <div>
                          <p className="text-purple-300/70 text-sm">Adres</p>
                          <p className="text-white font-medium">{selectedCustomer.address}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Active Shipments */}
                <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur">
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Package className="w-5 h-5 text-purple-400" />
                      <h4 className="text-lg font-semibold text-white">Aktif Kargolar</h4>
                    </div>
                    <CustomerShipments customerId={selectedCustomer.id} />
                  </div>
                </Card>
              </div>
            ) : (
              <Card className="border-purple-500/30 bg-slate-800/50 backdrop-blur h-full flex items-center justify-center">
                <div className="text-center p-12">
                  <p className="text-purple-300/70">Müşteri seçin detaiları görmek için</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function CustomerShipments({ customerId }: { customerId: string }) {
  const shipments = dataStore.getShipmentsByCustomer(customerId)

  if (shipments.length === 0) {
    return <p className="text-purple-300/70 text-center py-8">Aktif kargo bulunmuyor</p>
  }

  return (
    <div className="space-y-3">
      {shipments.map((shipment) => (
        <div key={shipment.id} className="p-4 bg-slate-700/30 border border-purple-500/20 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-white">{shipment.trackingNumber}</span>
            <Badge
              className={`text-xs ${
                shipment.currentLocation.status === "delivered"
                  ? "bg-green-600"
                  : shipment.currentLocation.status === "in_transit"
                    ? "bg-blue-600"
                    : "bg-yellow-600"
              }`}
            >
              {shipment.currentLocation.status === "delivered"
                ? "Teslim Edildi"
                : shipment.currentLocation.status === "in_transit"
                  ? "Yolda"
                  : "Bekleniyor"}
            </Badge>
          </div>
          <p className="text-sm text-purple-300">
            {shipment.origin.city} → {shipment.destination.city}
          </p>
          <p className="text-xs text-purple-300/50 mt-2">Mevcut konum: {shipment.currentLocation.city}</p>
        </div>
      ))}
    </div>
  )
}
