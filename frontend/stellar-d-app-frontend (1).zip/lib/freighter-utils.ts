"use client"

export interface WalletSession {
  publicKey: string
  isConnected: boolean
  xlmBalance: number | null
  network: "public" | "testnet"
}

// Demo wallet addresses for testing
const DEMO_WALLETS = [
  "GBBD47UZM2HO7A7A34DQWBHPUWV3O3F2G4KQWYSZ3VLCHW77RXOVVEHP",
  "GDB32Z2KGWHQIJHFLNFH4K2FG2JKYFZL7STVFXNL3L7K5DQQHPZ4K2",
  "GDRWYSZCNUQTYWFUDJC5D3NCZLKM2HS7CGKZABQCWEKYMFV6LLBYZ3DU",
]

// In-memory session storage
let currentSession: WalletSession | null = null

export async function connectFreighter(): Promise<WalletSession> {
  try {
    const freighterApi = (window as any).freighterApi

    if (freighterApi && typeof freighterApi.requestAccess === "function") {
      const result = await freighterApi.requestAccess()

      if (result?.error || !result?.address) {
        throw new Error(result?.error || "No address returned")
      }

      const publicKey = result.address
      console.log("[v0] Connected with Freighter:", publicKey)

      const session: WalletSession = {
        publicKey,
        isConnected: true,
        xlmBalance: null,
        network: "public",
      }

      currentSession = session
      localStorage.setItem("stellar-session", JSON.stringify(session))
      return session
    }

    throw new Error("Freighter not available")
  } catch (error) {
    console.log("[v0] Freighter not available, using demo mode")

    const publicKey = DEMO_WALLETS[Math.floor(Math.random() * DEMO_WALLETS.length)]

    const session: WalletSession = {
      publicKey,
      isConnected: true,
      xlmBalance: null,
      network: "public",
    }

    currentSession = session
    localStorage.setItem("stellar-session", JSON.stringify(session))

    console.log("[v0] Connected with demo wallet:", publicKey)
    return session
  }
}

export async function fetchXLMBalance(publicKey: string): Promise<number> {
  try {
    const response = await fetch(`https://horizon.stellar.org/accounts/${publicKey}`)
    if (!response.ok) {
      throw new Error("Failed to fetch balance")
    }

    const data = await response.json()
    const nativeBalance = data.balances.find((balance: any) => balance.asset_type === "native")
    return Number.parseFloat(nativeBalance?.balance || "0")
  } catch (error) {
    console.error("[v0] Error fetching XLM balance:", error)
    return 0
  }
}

export function getCurrentSession(): WalletSession | null {
  if (currentSession) return currentSession

  const stored = localStorage.getItem("stellar-session")
  if (stored) {
    try {
      currentSession = JSON.parse(stored)
      return currentSession
    } catch (e) {
      console.error("[v0] Error parsing stored session:", e)
    }
  }

  return null
}

export function disconnectWallet(): void {
  currentSession = null
  if (typeof window !== "undefined") {
    localStorage.removeItem("stellar-session")
    localStorage.removeItem("stellar-wallet")
  }
}

export function updateSessionBalance(balance: number): void {
  if (currentSession) {
    currentSession.xlmBalance = balance
    localStorage.setItem("stellar-session", JSON.stringify(currentSession))
  }
}
