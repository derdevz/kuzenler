// In-memory data store for customers and shipments
// In production, this would connect to a blockchain or database

export interface Customer {
  id: string
  walletAddress: string
  name: string
  email: string
  phone: string
  address: string
  createdAt: Date
}

export interface Product {
  id: string
  customerId: string
  name: string
  description: string
  quantity: number
  status: "pending" | "in_transit" | "delivered"
  origin?: string // added origin and destination cities
  destination?: string
  createdAt: Date
}

export interface ShipmentLocation {
  city: string
  country: string
  timestamp: Date
  status: "pending" | "in_transit" | "delivered" | "delayed"
}

export interface Shipment {
  id: string
  customerId: string
  productId: string
  trackingNumber: string
  origin: ShipmentLocation
  destination: ShipmentLocation
  currentLocation: ShipmentLocation
  estimatedDelivery: Date
  route: ShipmentLocation[]
  createdAt: Date
}

class DataStore {
  private customers: Map<string, Customer> = new Map()
  private products: Map<string, Product> = new Map()
  private shipments: Map<string, Shipment> = new Map()
  private adminWallets: Set<string> = new Set()

  constructor() {
    this.loadAdminConfig()
  }

  private async loadAdminConfig() {
    try {
      const response = await fetch("/admin-config.json")
      const config = await response.json()
      this.adminWallets = new Set(config.adminWallets || [])
      console.log("[v0] Admin wallets loaded:", this.adminWallets.size)
    } catch (error) {
      console.error("[v0] Failed to load admin config:", error)
    }
  }

  isAdmin(walletAddress: string): boolean {
    return this.adminWallets.has(walletAddress)
  }

  // Customer methods
  addCustomer(customer: Omit<Customer, "id" | "createdAt">): Customer {
    const newCustomer: Customer = {
      ...customer,
      id: `cust_${Date.now()}`,
      createdAt: new Date(),
    }
    this.customers.set(newCustomer.id, newCustomer)
    return newCustomer
  }

  getCustomerByWallet(walletAddress: string): Customer | undefined {
    return Array.from(this.customers.values()).find((c) => c.walletAddress === walletAddress)
  }

  getCustomer(id: string): Customer | undefined {
    return this.customers.get(id)
  }

  getAllCustomers(): Customer[] {
    return Array.from(this.customers.values())
  }

  updateCustomer(id: string, updates: Partial<Customer>): Customer | undefined {
    const customer = this.customers.get(id)
    if (!customer) return undefined
    const updated = { ...customer, ...updates }
    this.customers.set(id, updated)
    return updated
  }

  // Product methods
  addProduct(product: Omit<Product, "id" | "createdAt">): Product {
    const newProduct: Product = {
      ...product,
      id: `prod_${Date.now()}`,
      createdAt: new Date(),
    }
    this.products.set(newProduct.id, newProduct)

    if (product.origin && product.destination) {
      this.addShipment({
        customerId: product.customerId,
        productId: newProduct.id,
        trackingNumber: `TRK-${Date.now()}`,
        origin: {
          city: product.origin,
          country: "Türkiye",
          timestamp: new Date(),
          status: "pending",
        },
        destination: {
          city: product.destination,
          country: "Türkiye",
          timestamp: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          status: "pending",
        },
        currentLocation: {
          city: product.origin,
          country: "Türkiye",
          timestamp: new Date(),
          status: "pending",
        },
        estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        route: [
          {
            city: product.origin,
            country: "Türkiye",
            timestamp: new Date(),
            status: "pending",
          },
        ],
      })
    }

    return newProduct
  }

  getProduct(id: string): Product | undefined {
    return this.products.get(id)
  }

  getProductsByCustomer(customerId: string): Product[] {
    return Array.from(this.products.values()).filter((p) => p.customerId === customerId)
  }

  updateProduct(id: string, updates: Partial<Product>): Product | undefined {
    const product = this.products.get(id)
    if (!product) return undefined
    const updated = { ...product, ...updates }
    this.products.set(id, updated)
    return updated
  }

  deleteProduct(id: string): boolean {
    return this.products.delete(id)
  }

  // Shipment methods
  addShipment(shipment: Omit<Shipment, "id" | "createdAt">): Shipment {
    const newShipment: Shipment = {
      ...shipment,
      id: `ship_${Date.now()}`,
      createdAt: new Date(),
    }
    this.shipments.set(newShipment.id, newShipment)
    return newShipment
  }

  getShipment(id: string): Shipment | undefined {
    return this.shipments.get(id)
  }

  getShipmentsByCustomer(customerId: string): Shipment[] {
    return Array.from(this.shipments.values()).filter((s) => s.customerId === customerId)
  }

  updateShipmentStatus(id: string, status: ShipmentLocation): Shipment | undefined {
    const shipment = this.shipments.get(id)
    if (!shipment) return undefined
    shipment.currentLocation = status
    shipment.route.push(status)
    this.shipments.set(id, shipment)
    return shipment
  }

  getAllShipments(): Shipment[] {
    return Array.from(this.shipments.values())
  }
}

// Global store instance
export const dataStore = new DataStore()

// Initialize with sample data
function initializeSampleData() {
  const customer1 = dataStore.addCustomer({
    walletAddress: "GDB4K2",
    name: "Ahmet Yılmaz",
    email: "ahmet@example.com",
    phone: "+90 555 123 4567",
    address: "İstanbul, Türkiye",
  })

  const customer2 = dataStore.addCustomer({
    walletAddress: "GDFX9L",
    name: "Fatma Öztürk",
    email: "fatma@example.com",
    phone: "+90 555 987 6543",
    address: "Ankara, Türkiye",
  })

  // Sample products and shipments for demonstration
  const product1 = dataStore.addProduct({
    customerId: customer1.id,
    name: "Elektronik Kitap Okuyucu",
    description: "E-ink display, 6 inç, WiFi bağlantı",
    quantity: 2,
    status: "in_transit",
    origin: "Shanghai",
    destination: "İstanbul",
  })

  const product2 = dataStore.addProduct({
    customerId: customer2.id,
    name: "Kablosuz Kulaklık",
    description: "Aktif gürültü engelleme, 30 saat pil ömrü",
    quantity: 1,
    status: "pending",
  })

  // Sample shipments
  dataStore.addShipment({
    customerId: customer1.id,
    productId: product1.id,
    trackingNumber: "TRK001",
    origin: {
      city: "Shanghai",
      country: "Çin",
      timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      status: "pending",
    },
    destination: {
      city: "İstanbul",
      country: "Türkiye",
      timestamp: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
      status: "in_transit",
    },
    currentLocation: {
      city: "Dubai",
      country: "UAE",
      timestamp: new Date(),
      status: "in_transit",
    },
    estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    route: [
      {
        city: "Shanghai",
        country: "Çin",
        timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        status: "pending",
      },
      {
        city: "Hong Kong",
        country: "Hong Kong",
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        status: "in_transit",
      },
      {
        city: "Dubai",
        country: "UAE",
        timestamp: new Date(),
        status: "in_transit",
      },
    ],
  })
}

// Initialize sample data on first load
if (typeof window !== "undefined") {
  initializeSampleData()
}
